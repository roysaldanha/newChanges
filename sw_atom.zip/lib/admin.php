<?php

/**
 * Add Theme Options page.
 */
function ya_theme_admin_page(){
	add_theme_page(
		__('Theme Options', 'sw_atom'),
		__('Theme Options', 'sw_atom'),
		'manage_options',
		'ya_theme_options',
		'ya_theme_admin_page_content'
	);
}
add_action('admin_menu', 'ya_theme_admin_page', 49);

function ya_theme_admin_page_content(){ ?>
	<div class="wrap">
		<h2><?php esc_html_e( 'YA Advanced Options Page', 'sw_atom' ); ?></h2>
		<?php do_action( 'ya_theme_admin_content' ); ?>
	</div>
<?php
}