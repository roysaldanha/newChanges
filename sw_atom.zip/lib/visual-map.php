<?php 
add_action( 'vc_before_init', 'YA_shortcodeVC' );
function YA_shortcodeVC(){
$target_arr = array(
	__( 'Same window', 'sw_atom' ) => '_self',
	__( 'New window', 'sw_atom' ) => "_blank"
);
$link_category = array( __( 'All Links', 'sw_atom' ) => '' );
$link_cats     = get_categories();
if ( is_array( $link_cats ) ) {
	foreach ( $link_cats as $link_cat ) {
		$link_category[ $link_cat->name ] = $link_cat->term_id;
	}
}
//category product
$terms = get_terms( 'product_cat', array( 'parent' => 0, 'hide_emty' => false ) );
	if( count( $terms ) == 0 ){
		return ;
	}
	$term = array( __( 'Select Category Product', 'sw_atom' ) => '' );
	foreach( $terms as $cat ){
		$term[$cat->name] = $cat -> term_id;
	}
// hot category
$terms1 = get_terms( 'product_cat', array( 'parent' => 0, 'hide_emty' => false ) );
	if( count( $terms1 ) == 0 ){
		return ;
	}
	$term = array();
	foreach( $terms1 as $cat ){
		$term1[$cat->name] = $cat -> term_id;
	}	
$args =
 array(
			'type' => 'post',
			'child_of' => 0,
			'parent' => 0,
			'orderby' => 'name',
			'order' => 'ASC',
			'hide_empty' => false,
			'hierarchical' => 1,
			'exclude' => '',
			'include' => '',
			'number' => '',
			'taxonomy' => 'product_cat',
			'pad_counts' => false,

		);
		$product_categories_dropdown = array( __( 'Select Category Product', 'sw_atom' ) => '' );;
		$categories = get_categories( $args );
		foreach($categories as $category){
			$product_categories_dropdown[$category->name] = $category -> term_id;
		}
$menu_locations_array = array( __( 'All Links', 'sw_atom' ) => '' );
$menu_locations = wp_get_nav_menus();	
foreach ($menu_locations as $menu_location){
	$menu_locations_array[$menu_location->name] = $menu_location -> term_id;
}

/* YTC VC */
// ytc tesminial

vc_map( array(
	'name' => 'YTC_ ' . __( 'Testimonial Slide', 'sw_atom' ),
	'base' => 'testimonial_slide',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_atom' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'The tesminial on your site', 'sw_atom' ),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_atom' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Style title', 'sw_atom' ),
			'param_name' => 'style_title',
			'value' => array(
				'Select type',
				__( 'Style title 1', 'sw_atom' ) => 'title1',
				__( 'Style title 2', 'sw_atom' ) => 'title2',
				__( 'Style title 3', 'sw_atom' ) => 'title3'
			),
			'description' =>__( 'What text use as a style title. Leave blank to use default style title.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of posts to show', 'sw_atom' ),
			'param_name' => 'numberposts',
			'admin_label' => true
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Excerpt length (in words)', 'sw_atom' ),
			'param_name' => 'length',
			'description' => __( 'Excerpt length (in words).', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Template', 'sw_atom' ),
			'param_name' => 'type',
			'value' => array(
				__('Indicators Up','sw_atom') => 'indicators_up',
				__( 'Slide Style 1', 'sw_atom' ) => 'slide1',
				__('Slide Style 2','sw_atom') => 'slide2',
				__( 'Style Our Service', 'sw_atom' ) => 'ourservice'
				
			),
			'description' => sprintf( __( 'Chose template for testimonial', 'sw_atom' ) )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order way', 'sw_atom' ),
			'param_name' => 'order',
			'value' => array(
				__( 'Descending', 'sw_atom' ) => 'DESC',
				__( 'Ascending', 'sw_atom' ) => 'ASC'
			),
			'description' => __( 'Designates the ascending or descending order. More at %s.', 'sw_atom' )
		),
				
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order by', 'sw_atom' ),
			'param_name' => 'orderby',
			'value' => array(
				'Select orderby',
				__( 'Date', 'sw_atom' ) => 'date',
				__( 'ID', 'sw_atom' ) => 'ID',
				__( 'Author', 'sw_atom' ) => 'author',
				__( 'Title', 'sw_atom' ) => 'title',
				__( 'Modified', 'sw_atom' ) => 'modified',
				__( 'Random', 'sw_atom' ) => 'rand',
				__( 'Comment count', 'sw_atom' ) => 'comment_count',
				__( 'Menu order', 'sw_atom' ) => 'menu_order'
			),
			'description' => __( 'Select how to sort retrieved posts. More at %s.', 'sw_atom' )
		),
			
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_atom' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_atom' )
		)
	)
) );
//ytc our brand
vc_map( array(
	'name' => 'YTC_ ' . __( 'Brand', 'sw_atom' ),
	'base' => 'OurBrand',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_atom' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'The best sale  product on your site', 'sw_atom' ),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_atom' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Style title', 'sw_atom' ),
			'param_name' => 'style_title',
			'value' => array(
				'Select type',
				__( 'Style title 1', 'sw_atom' ) => 'title1',
				__( 'Style title 2', 'sw_atom' ) => 'title2',
				__( 'Style title 3', 'sw_atom' ) => 'title3',
				__( 'Style title 4', 'sw_atom' ) => 'title4'
			),
			'description' =>__( 'What text use as a style title. Leave blank to use default style title.', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Type display', 'sw_atom' ),
			'param_name' => 'type',
			'value' => array(
				'Select type',
				__( 'Type default', 'sw_atom' ) => 'default',
				__( 'Type slide', 'sw_atom' ) => 'slide',
			),
			'description' =>__( 'type you want display.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of posts to show', 'sw_atom' ),
			'param_name' => 'numberposts',
			'admin_label' => true
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order way', 'sw_atom' ),
			'param_name' => 'order',
			'value' => array(
				__( 'Descending', 'sw_atom' ) => 'DESC',
				__( 'Ascending', 'sw_atom' ) => 'ASC'
			),
			'description' => __( 'Designates the ascending or descending order. More at %s.', 'sw_atom' )
		),
				
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order by', 'sw_atom' ),
			'param_name' => 'orderby',
			'value' => array(
				'Select orderby',
				__( 'Date', 'sw_atom' ) => 'date',
				__( 'ID', 'sw_atom' ) => 'ID',
				__( 'Author', 'sw_atom' ) => 'author',
				__( 'Title', 'sw_atom' ) => 'title',
				__( 'Modified', 'sw_atom' ) => 'modified',
				__( 'Random', 'sw_atom' ) => 'rand',
				__( 'Comment count', 'sw_atom' ) => 'comment_count',
				__( 'Menu order', 'sw_atom' ) => 'menu_order'
			),
			'description' => __( 'Select how to sort retrieved posts. More at %s.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Speed slide', 'sw_atom' ),
			'param_name' => 'interval',
			'description' => __( 'Speed for slide', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
		    'heading' => __( 'Effect slide', 'sw_atom' ),
			'param_name' => 'effect',
			'value' => array(
				__( 'Slide', 'sw_atom' ) => 'slide',
				__( 'Fade', 'sw_atom' ) => 'fade',
			),
				'description' => __( 'Effect for slide', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
		    'heading' => __( 'Hover slide', 'sw_atom' ),
			'param_name' => 'hover',
			'value' => array(
				__( 'Yes', 'sw_atom' ) => 'hover',
				__( 'No', 'sw_atom' ) => '',
			),
				'description' => __( 'Hover for slide', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
		    'heading' => __( 'Swipe slide', 'sw_atom' ),
			'param_name' => 'swipe',
			'value' => array(
				__( 'Yes', 'sw_atom' ) => 'yes',
				__( 'No', 'sw_atom' ) => 'no',
			),
				'description' => __( 'Swipe for slide', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns >1200px:', 'sw_atom' ),
			'param_name' => 'columns',
			'description' => __( 'Number colums you want display  > 1200px.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns on 768px to 1199px:', 'sw_atom' ),
			'param_name' => 'columns1',
			'description' => __( 'Number colums you want display  on 768px to 1199px.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns on 480px to 767px:', 'sw_atom' ),
			'param_name' => 'columns2',
			'description' => __( 'Number colums you want display  on 480px to 767px.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns on 321px to 479px:', 'sw_atom' ),
			'param_name' => 'columns3',
			'description' => __( 'Number colums you want display  on 321px to 479px.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of Columns in 320px or less than:', 'sw_atom' ),
			'param_name' => 'columns4',
			'description' => __( 'Number colums you want display  in 320px or less than.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_atom' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_atom' )
		)
	)
) );
//// vertical mega menu
vc_map( array(
	'name' => 'YTC ' . __( 'vertical mega menu', 'sw_atom' ),
	'base' => 'ya_mega_menu',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_atom' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'Display vertical mega menu', 'sw_atom' ),
	'params' => array(
	    array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_atom' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_atom' )
		),
		array(
			'param_name'    => 'style',
			'type'          => 'dropdown',
			'value'         => array(
				'Style Default' => '',
				'Style 1'       => 'style1'
			), // here I'm stuck
			'heading'       => __('Style Vertical Menu', 'sw_atom'),
			'description'   => '',
			'holder'        => 'div'
		),
	    array(
			'param_name'    => 'menu_locate',
			'type'          => 'dropdown',
			'value'         => $menu_locations_array, // here I'm stuck
			'heading'       => __('Category menu:', 'sw_atom'),
			'description'   => '',
			'holder'        => 'div',
			'class'         => ''
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Theme shortcode want display', 'sw_atom' ),
			'param_name' => 'widget_template',
			'value' => array(
				__( 'default', 'sw_atom' ) => 'default',
			),
			'description' => sprintf( __( 'Select different style menu.', 'sw_atom' ) )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_atom' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_atom' )
		),			
	)
));
///// Gallery 
vc_map( array(
	'name' => __( 'YTC_Gallery', 'sw_atom' ),
	'base' => 'gallerys',
	'icon' => 'icon-wpb-images-carousel',
	'category' => __( 'My shortcodes', 'sw_atom' ),
	'description' => __( 'Animated carousel with images', 'sw_atom' ),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_atom' ),
			'param_name' => 'title',
			'description' => __( 'Enter text which will be used as widget title. Leave blank if no title is needed.', 'sw_atom' )
		),
		array(
			'type' => 'attach_images',
			'heading' => __( 'Images', 'sw_atom' ),
			'param_name' => 'ids',
			'value' => '',
			'description' => __( 'Select images from media library.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'gallery size', 'sw_atom' ),
			'param_name' => 'size',
			'description' => __( 'Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use "thumbnail" size. If used slides per view, this will be used to define carousel wrapper size.', 'sw_atom' )
		),
		
		array(
			'type' => 'dropdown',
			'heading' => __( 'Gallery caption', 'sw_atom' ),
			'param_name' => 'caption',
			'value' => array(
				__( 'true', 'sw_atom' ) => 'true',
				__( 'false', 'sw_atom' ) => 'false'
			),
			'description' => __( 'Images display caption true or false', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Gallery type', 'sw_atom' ),
			'param_name' => 'type',
			'value' => array(
				__( 'column', 'sw_atom' ) => 'column',
				__( 'slide', 'sw_atom' ) => 'slide',
				__( 'flex', 'sw_atom' ) => 'flex'
			),
			'description' => __( 'Images display type', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'gallery columns', 'sw_atom' ),
			'param_name' => 'columns',
			'description' => __( 'Enter gallery columns. Example: 1,2,3,4 ... Only use gallery type="column".', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Slider speed', 'sw_atom' ),
			'param_name' => 'interval',
			'value' => '5000',
			'description' => __( 'Duration of animation between slides (in ms)', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Gallery event', 'sw_atom' ),
			'param_name' => 'event',
			'value' => array(
				__( 'slide', 'sw_atom' ) => 'slide',
				__( 'fade', 'sw_atom' ) => 'fade'
			),
			'description' => __( 'event slide images', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_atom' ),
			'param_name' => 'class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_atom' )
		)
		)
) );
/////////////////// best sale /////////////////////
vc_map( array(
	'name' => 'YTC_' . __( 'Best Sale', 'sw_atom' ),
	'base' => 'BestSale',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_atom' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'Display bestseller', 'sw_atom' ),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Widget title', 'sw_atom' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Style title', 'sw_atom' ),
			'param_name' => 'style_title',
			'description' =>__( 'What text use as a style title. Leave blank to use default style title.', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Template', 'sw_atom' ),
			'param_name' => 'template',
			'value' => array(
				'Select type',
				__( 'Default', 'sw_atom' ) => 'default',
				__( 'Slide', 'sw_atom' ) => 'slide',
			),
			'description' => sprintf( __( 'Select different style best sale.', 'sw_atom' ) )
		),
		
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of posts to show', 'sw_atom' ),
			'param_name' => 'number',
			'admin_label' => true
		),
		
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_atom' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_atom' )
		),	
	)
) );
/////////////////// YA Recommend/////////////////////
vc_map( array(
	'name' =>  __( 'YA Recommend Products', 'sw_atom' ),
	'base' => 'ya_recommend',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_atom' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'Recommend Products', 'sw_atom' ),
	'params' => array(
		array(
			'type' => 'textfield',
			'heading' => __( 'Title', 'sw_atom' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
			'holder' => 'div',
			'class' => '',
			'heading' => __( "Category", 'sw_atom' ),
			'param_name' => "category",
			'value' => $term,
			'description' => __( "Select Categories", 'sw_atom' )
		 ),
		array(
			'type' => 'textfield',
			'heading' => __( 'Number of product to show', 'sw_atom' ),
			'param_name' => 'numberposts',
			'admin_label' => true
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order way', 'sw_atom' ),
			'param_name' => 'order',
			'value' => array(
				__( 'Descending', 'sw_atom' ) => 'DESC',
				__( 'Ascending', 'sw_atom' ) => 'ASC'
			),
			'description' => __( 'Designates the ascending or descending order. More at %s.', 'sw_atom' )
		),
		array(
			'type' => 'dropdown',
			'heading' => __( 'Order by', 'sw_atom' ),
			'param_name' => 'orderby',
			'value' => array(
				'Select orderby',
				__( 'Date', 'sw_atom' ) => 'date',
				__( 'ID', 'sw_atom' ) => 'ID',
				__( 'Author', 'sw_atom' ) => 'author',
				__( 'Title', 'sw_atom' ) => 'title',
				__( 'Modified', 'sw_atom' ) => 'modified',
				__( 'Random', 'sw_atom' ) => 'rand',
				__( 'Comment count', 'sw_atom' ) => 'comment_count',
				__( 'Menu order', 'sw_atom' ) => 'menu_order'
			),
			'description' => __( 'Select how to sort retrieved posts. More at %s.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_atom' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_atom' )
		),	
	)
) );

/////////////////// ya Choose us/////////////////////
vc_map( array(
	'name' => 'YTC_' . __( 'Why Choose Us', 'sw_atom' ),
	'base' => 'block_chooseus',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_atom' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'Display Content Blog Why Choose Us', 'sw_atom' ),
	'params' => array(
			array(
			'type' => 'textfield',
			'heading' => __( 'Title', 'sw_atom' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_atom' )
		),
		array(
			'type' => 'attach_images',
			'heading' => __( 'Image', 'sw_atom' ),
			'param_name' => 'image',
			'description' => ''
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Description', 'sw_atom' ),
			'param_name' => 'description',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_atom' )
		),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_atom' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_atom' )
		),
	)
));

/////////////////// ya Hot Category/////////////////////
vc_map( array(
	'name' => 'YTC_' . __( 'Hot Category', 'sw_atom' ),
	'base' => 'hot_category',
	'icon' => 'icon-wpb-ytc',
	'category' => __( 'My shortcodes', 'sw_atom' ),
	'class' => 'wpb_vc_wp_widget',
	'weight' => - 50,
	'description' => __( 'Display Hot Product Category', 'sw_atom' ),
	'params' => array(
			array(
			'type' => 'textfield',
			'heading' => __( 'Title', 'sw_atom' ),
			'param_name' => 'title',
			'description' => __( 'What text use as a widget title. Leave blank to use default widget title.', 'sw_atom' )
		),
		 array(
			'type' => 'checkbox',
			'holder' => 'div',
			'class' => '',
			'heading' => __( "Category", 'sw_atom' ),
			'param_name' => "categories",
			'value' => $term1,
			'description' => __( "Select Categories", 'sw_atom' )
		 ),
		array(
			'type' => 'textfield',
			'heading' => __( 'Extra class name', 'sw_atom' ),
			'param_name' => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'sw_atom' )
		),
	)
));

}
?>