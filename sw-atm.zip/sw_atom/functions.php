<?php 
if ( !defined( 'ICL_LANGUAGE_CODE' ) && !defined('__THEME__') ){
	define( '__THEME__', 'sw_atom' );
}else{
	define( '__THEME__', 'sw_atom'.ICL_LANGUAGE_CODE );
}

/**
 * Variables
 */
require_once (get_template_directory().'/lib/defines.php');
/**
 * Roots includes
 */
require_once (get_template_directory().'/lib/classes.php');		// Utility functions
require_once (get_template_directory().'/lib/utils.php');			// Utility functions
require_once (get_template_directory().'/lib/init.php');			// Initial theme setup and constants
require_once (get_template_directory().'/lib/cleanup.php');		// Cleanup
require_once (get_template_directory().'/lib/nav.php');			// Custom nav modifications
require_once (get_template_directory().'/lib/widgets.php');		// Sidebars and widgets
require_once (get_template_directory().'/lib/scripts.php');		// Scripts and stylesheets
require_once (get_template_directory().'/lib/shortcodes.php');	// Utility functions
require_once locate_template('/lib/less.php');			// Custom functions
require_once (get_template_directory().'/lib/plugin-requirement.php');			// Custom functions
require_once (get_template_directory().'/lib/import/sw-import.php' );
if( class_exists( 'WooCommerce' ) ){
	require_once (get_template_directory().'/lib/plugins/currency-converter/currency-converter.php'); // currency converter
	require_once (get_template_directory().'/lib/woocommerce-hook.php');	// Utility functions
}
if( class_exists( 'WooCommerce' ) && class_exists( 'Vc_Manager' ) ){
	require_once (get_template_directory().'/lib/visual-map.php');
}
// add image thumbnail latest blog
add_image_size( 'ya-latest-blog', 270, 200, true);
// add image thumbnail latest blog2
add_image_size( 'ya-latest-blog2', 220, 165, true);
// add image thumbnail grid blog
add_image_size( 'ya_grid_blog', 420,250, true);
// add image thumbnail related post
add_image_size( 'ya_related_post', 270,175, true);
// add image thumbnail r
add_image_size( 'ya_popular_post', 100,72, true);
// add image thumbnail r
add_image_size( 'ya_product_thumb', 100,72, true);
// add image blog detail
add_image_size( 'ya_detail_thumb', 870,370, true);
// add image blog detail
add_image_size( 'ya_first_thumb',170,140, true);

if( !is_admin() ) {
	function Ya_SearchFilter( $query ) {
		if ( $query->is_search ) {
			$query->set( 'post_type', array( 'post', 'product' ) );
		}
		return $query;
	}
	add_filter('pre_get_posts','Ya_SearchFilter');
}
