<?php
/**
 * sw_atom initial setup and constants
 */
function ya_setup() {
	// Make theme available for translation
	load_theme_textdomain('sw_atom', get_template_directory() . '/lang');

	// Register wp_nav_menu() menus (http://codex.wordpress.org/Function_Reference/register_nav_menus)
	register_nav_menus(array(
		//'header_menu' => __('Header Menu', 'sw_atom'),
		//'footer_menu' => __('Footer Menu', 'sw_atom'),
		'primary_menu' => __('Primary Menu', 'sw_atom'),
	));
	
	
	add_theme_support( 'automatic-feed-links' );

	add_theme_support( "title-tag" );
	
	add_theme_support( 'sw_theme' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	if( ya_options()->getCpanelValue( 'product_zoom' ) ) :
		add_theme_support( 'wc-product-gallery-zoom' );
	endif;

	// Add post thumbnails (http://codex.wordpress.org/Post_Thumbnails)
	add_theme_support('post-thumbnails');	

	// Add post formats (http://codex.wordpress.org/Post_Formats)
	add_theme_support('post-formats', array('aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat'));
	
	// Custom image header
	$header_arr = array(
		'default-image' => get_template_directory_uri().'/assets/img/logo-default.png',
		'uploads'       => true
	);
	add_theme_support( 'custom-header', $header_arr );
	
	// Custom Background 
	$bgarr = array(
		'default-color' => 'ffffff',
		'default-image' => '',
	);
	add_theme_support( 'custom-background', $bgarr );
	
	// Tell the TinyMCE editor to use a custom stylesheet
	add_editor_style('/assets/css/editor-style.css');
	
	new YA_Menu();
}
add_action('after_setup_theme', 'ya_setup');

