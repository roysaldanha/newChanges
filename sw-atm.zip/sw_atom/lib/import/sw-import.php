<?php 
function sw_import_files() { 
	return array(
		array(
			'import_file_name'          => 'Home Page 1',
			'page_title'				=> 'Home',
			'local_import_file'         => trailingslashit( get_template_directory() ) . 'lib/import/demo-1/demo-content.xml',
			'local_import_widget_file'  => trailingslashit( get_template_directory() ) . 'lib/import/demo-1/widgets.json',
			'local_import_revslider'  	=> array( 
				'slide1' => trailingslashit( get_template_directory() ) . 'lib/import/demo-1/slide-1.zip' 
			),
			'local_import_options'        => array(
				array(
					'file_path'   => trailingslashit( get_template_directory() ) . 'lib/import/demo-1/theme_options.txt',
					'option_name' => 'sw_atom',
				),
			),
			'menu_locate'	=> array(
				'primary_menu' 	=> 'Primary Menu',   /* menu location => menu name for that location */
			),
			'import_preview_image_url'     => get_template_directory_uri() . '/lib/import/demo-1/1.png',
			'import_notice'                => __( 'After you import this demo, you will have to setup the slider separately. This import maybe finish on 10-15 minutes', 'revo' ),
			'preview_url'                  => esc_url( 'http://demo.wpthemego.com/themes/sw_atom/?page_id=5&header_style=style1' ),
		),
	
		array(
			'import_file_name'          => 'Home Page 2',
			'page_title'				=> 'Home Page 2',
			'local_import_file'         => trailingslashit( get_template_directory() ) . 'lib/import/demo-1/demo-content.xml',
			'local_import_widget_file'  => trailingslashit( get_template_directory() ) . 'lib/import/demo-1/widgets.json',
			'local_import_revslider'  	=> array( 
				'slide1' => trailingslashit( get_template_directory() ) . 'lib/import/demo-2/slide-2.zip' 
			),
			'local_import_options'         => array(
				array(
					'file_path'   => trailingslashit( get_template_directory() ) . 'lib/import/demo-2/theme_options.txt',
					'option_name' => 'sw_atom',
				),
			),
			'menu_locate'	=> array(
				'primary_menu' => 'Primary Menu',   /* menu location => menu name for that location */
				'vertical_menu' => 'Menu Vertical Category'
			),
			'import_preview_image_url'     => get_template_directory_uri() . '/lib/import/demo-2/2.png',
			'import_notice'                => __( 'After you import this demo, you will have to setup the slider separately. This import maybe finish on 10-15 minutes', 'revo' ),
			'preview_url'                  => esc_url( 'http://demo.wpthemego.com/themes/sw_atom/?page_id=464&header_style=style2' ),
		),
		
		array(
			'import_file_name'          => 'Home Page 3',
			'page_title'				=> 'Home Page 3',
			'local_import_file'         => trailingslashit( get_template_directory() ) . 'lib/import/demo-1/demo-content.xml',
			'local_import_widget_file'  => trailingslashit( get_template_directory() ) . 'lib/import/demo-1/widgets.json',
			'local_import_revslider'  		 => array( 
				'slide1' => trailingslashit( get_template_directory() ) . 'lib/import/demo-3/slider-3.zip' 
			),
			'local_import_options'         => array(
				array(
					'file_path'   => trailingslashit( get_template_directory() ) . 'lib/import/demo-3/theme_options.txt',
					'option_name' => 'sw_atom',
				),
			),
			'menu_locate'	=> array(
				'primary_menu' => 'Primary Menu',
				'vertical_menu1' => 'Menu Vertical Category2',   /* menu location => menu name for that location */
			),
			'import_preview_image_url'     => get_template_directory_uri() . '/lib/import/demo-3/3.png',
			'import_notice'                => __( 'After you import this demo, you will have to setup the slider separately. This import maybe finish on 10-15 minutes', 'revo' ),
			'preview_url'                  => esc_url( 'http://demo.wpthemego.com/themes/sw_atom/?page_id=527&header_style=style3&&scheme=blue' ),
		),
		
	);
}
add_filter( 'pt-ocdi/import_files', 'sw_import_files' );