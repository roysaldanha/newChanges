<?php  
	extract($instance);
	wp_nav_menu( array( 'menu' => $menu_locate, 'menu_class' => 'nav vertical-megamenu' ) );
?>