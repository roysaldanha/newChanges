<?php
$less_variables = array(
	'color'        => '#ed1c24',
	'a-color'      => '#ed1c24',
	'body-color'   => '#444',
	'border-color' => '#cecece',
	'url'     => "'../assets/img/default'",
);

