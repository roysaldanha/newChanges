<?php
$less_variables = array(
	'color'        => '#03a9f4',
	'a-color'      => 'desaturate(darken(@color, 20%),4%)',
	'body-color'   => '#444',
	'border-color' => '#cecece',
	'url'     => "'../assets/img/blue'",
);


