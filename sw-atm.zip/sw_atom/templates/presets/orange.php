<?php
$less_variables = array(
	'color'        => '#f39c12',
	'a-color'      => 'desaturate(darken(@color, 20%),4%)',
	'body-color'   => '#444',
	'border-color' => '#cecece',
	'url'     => "'../assets/img/orange'",
);


