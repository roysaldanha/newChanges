<?php
/**
 * Widget Style: Pull Right
 *
 */
$ws['pull-right'] = array(
		'before_title' => '<h3><span>',
		'after_title' => '</span></h3>',
		'before_widget' => '<div class="widget %1$s %2$s pull-right"><div class="widget-inner">',
		'after_widget' => '</div></div>',
	);