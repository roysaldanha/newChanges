<?php

$ws['style-slider'] = array(
		'before_title' => '<h2>',
		'after_title' => '</h2>',
		'before_widget' => '<div class="col-lg-9 widget %1$s %2$s"><div class="widget-inner">',
		'after_widget' => '</div></div>',
	);