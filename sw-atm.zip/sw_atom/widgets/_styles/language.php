<?php

$ws['language'] = array(
		'before_title' => '<h3>',
		'after_title' => '</h3>',
		'before_widget' => '<div class="widget %1$s %2$s widget_icl_lang_sel_widget"><div class="widget-inner">',
		'after_widget' => '</div></div>',
	);