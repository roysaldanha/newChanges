<?php
/**
 * Single Product Price, including microdata for SEO
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

?>
<div itemprop="offers">
	<p class="price"><?php echo $product->get_price_html(); ?></p>
</div>

<?php $stock = ( $product->is_in_stock() )? 'in-stock' : 'out-stock' ; ?>
<div class="product-stock <?php echo esc_attr( $stock ); ?>">
	 
	<span><?php echo ( $product->is_in_stock() )? __( 'Available in stock', 'sw_atom' ) : __( 'Out stock', 'sw_atom' ); ?></span>
</div>
